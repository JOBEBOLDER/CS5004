/*
 * 2024 spring CS5004
 * HW 2: Assignment 2: Methods, Packages and Exceptions
 * Hotel Rooms
 * Cathy Chen
 */

package hw2;

/** Represents a room in a hotel booking system.
 * This class handles room booking ,occupancy checks, and related information.
 */
public class Room {

  private final double price; // Price of the room per night.
  private int guestNumber; // Current number of guests in the room.
  private final RoomType roomType; // Type of the room.

  // constructor do not have any return type value even void
  /**
   *  Constructor for the Room class.
   *  Initializes a room with a specified type and price.
   * @param roomType The type of the room.
   * @param price The nightly price of the room.
   * @throws IllegalArgumentException if the price is negative.
   */
  public Room(RoomType roomType, double price) {
    if (price < 0) {
      throw new IllegalArgumentException("The price of a room cannot be negative!");

    }
    this.price = price;
    this.roomType = roomType;
    this.guestNumber = 0; // Initial guest count is zero.
  }

  /**
   * Determines the maximum number of guest allowed based on room types.
   * @return the maximum occupancy for the room.
   */
  private int getMaxOccupancy() {
    switch (roomType) {
      case SINGLE:
        return 1;
      case DOUBLE:
        return 2;
      case FAMILY:
        return 3;
      default:
        return 0; //  fallback-should not be reached
    }
  }

  /**
   * Checks if the room is currently available (no guests).
   * @return True if no guest are in the room,false otherwise.
   */
  public boolean isAvailable() {
    return guestNumber == 0;
  }

  /**
   * Try to book the rrom with a specified number of guests.
   * @param guests Booking is successful if the room is available and the number of
   *               guests within the room's capacity.
   * @return true if the booking is successful,false otherwise
   */
  @SuppressWarnings("checkstyle:FinalParameters")
  public boolean bookRoom(int guests) {
    if (isAvailable() == true && 0 < guests && guests <= getMaxOccupancy()) {
      this.guestNumber = guests;
      return true;
    }
    return false;

  }

  /**
   * Retrieves the current number of guests in the room.
   * @return the number of guests.
   */
  public int getNumberOfGuests() {
    return guestNumber;

  }


}
