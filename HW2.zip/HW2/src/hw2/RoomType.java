package hw2;

/**
 * Representation of the booking system have these following types of room.
 * has:single rooms, double rooms, and family rooms.
 */
public enum RoomType {
    SINGLE, DOUBLE, FAMILY

}
