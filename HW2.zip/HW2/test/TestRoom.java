/*
 * 2024 spring CS5004
 * HW 2: Assignment 1: Writing a simple class and testing it
 * ( Testing 1 Electric Vehicles)
 * Cathy Chen
 */

package hw2;

import org.junit.Test;

import static junit.framework.TestCase.*;
import static org.junit.Assert.assertThrows;

/**
 * Test class for the Room class.
 * This class performs unit tests to ensure the functionality of the Room class,
 * including room booking, checking room availability, and handling of invalid inputs.
 */
public class TestRoom {
  /**
   * Tests the functionality of booking a DOUBLE room.
   * Ensures that a room can be booked if the number of guests is within capacity,
   * and cannot be booked if the number of guests exceeds capacity.
   */
  @Test
  public void testDoubleRoom() {
    Room doubleRoom = new Room(RoomType.DOUBLE, 1000);
    assertTrue(doubleRoom.isAvailable());
    assertTrue(doubleRoom.bookRoom(2));
    assertFalse(doubleRoom.bookRoom(6));
    assertFalse(doubleRoom.isAvailable());
    assertEquals(2,doubleRoom.getNumberOfGuests());

  }

  /**
   * Tests the functionality of booking a FAMILY room.
   * Checks if the booking behaves correctly with valid and invalid guest numbers.
   */
  public void testFamilyRoom() {
    Room singleRoom = new Room(RoomType.FAMILY, 2000);
    assertTrue(singleRoom.isAvailable());
    assertTrue(singleRoom.bookRoom(3));
    assertFalse(singleRoom.bookRoom(8));
    assertFalse(singleRoom.isAvailable());
    assertEquals(3,singleRoom.getNumberOfGuests());
  }

  /**
   * Tests the functionality of booking a SINGLE room.
   * Verifies that the room can only be booked for one guest.
   */
  public void testSingleRoom() {
    Room singleRoom = new Room(RoomType.SINGLE, 800);
    assertTrue(singleRoom.isAvailable());
    assertTrue(singleRoom.bookRoom(1));
    assertFalse(singleRoom.bookRoom(3));
    assertFalse(singleRoom.isAvailable());
    assertEquals(1,singleRoom.getNumberOfGuests());
  }

  /**
   * Tests the Room constructor with an invalid price.
   * Expects an IllegalArgumentException to be thrown for negative prices.
   */
  @Test
  public void testInvalidPrice() {
    assertThrows(IllegalArgumentException.class, () -> new Room(RoomType.DOUBLE, -100));
  }

}
